// Generated from the single-page prototype. Edit freely.
export const UUID_TEXT: Record<string,string> = {
 "1": "A Version 1 UUID is built from the current time (counted in 100-nanosecond steps since 15 October 1582), a clock sequence and a node ID. Originally the node was the computer’s MAC address. This page uses a random node ID instead, as the standard allows, so your hardware address is never exposed. Version 1 values can be decoded to show when they were created.",
 "2": "A Version 2 UUID is the DCE Security variant of Version 1. Part of the timestamp is replaced by a local identifier, such as a user or group ID, and the domain is stored in the clock sequence. It is rarely used in modern software and many libraries do not support it. Pick a domain and a local ID above to build one.",
 "3": "A Version 3 UUID is generated from a namespace and a name using the MD5 hash. The same inputs always produce the same UUID. MD5 is weak for security, so Version 5 is usually preferred for new work, but Version 3 is still useful when you must match an existing system.",
 "4": "A Version 4 UUID is a 128-bit identifier made from random numbers. This page creates them with your browser’s secure random number generator, so nothing is sent to a server.",
 "5": "A Version 5 UUID is built from a namespace and a name using SHA-1. The same namespace and name always produce the same UUID.",
 "6": "A Version 6 UUID is a reordered Version 1 UUID. The timestamp bits are rearranged so the most significant part comes first, which makes values sort by creation time. It exists to help systems that already use Version 1. For new projects, Version 7 is usually the better choice.",
 "7": "A Version 7 UUID starts with a millisecond Unix timestamp followed by random bits, so values sort in the order they were created. That makes them a good fit for database keys.",
 "8": "A Version 8 UUID is reserved for custom, vendor-specific layouts. The standard fixes only the version and variant bits, and you decide what the other 122 bits mean. This page fills them with random data so you can see a valid Version 8 UUID. To use your own layout, set the bytes in your code."
};
export const GUID_DATA = [
 {
  "slug": "guid-generator",
  "title": "GUID Generator",
  "desc": "Create GUIDs in the Microsoft style, with braces and uppercase letters if you need them. Pick a type and a format, then copy or download.",
  "ver": "4",
  "fmt": "B",
  "up": true,
  "n": 5,
  "text": [
   [
    "GUID or UUID?",
    "A GUID is Microsoft's name for a UUID. Both are 128-bit identifiers with the same layout. GUIDs appear in .NET, SQL Server uniqueidentifier columns, the Windows registry and COM. They are usually written in uppercase, sometimes inside braces."
   ],
   [
    "Which type should I choose?",
    "Random (v4) is the standard choice. Time-ordered (v7) values sort by creation time. COMB GUIDs are designed to sort well in SQL Server."
   ]
  ]
 },
 {
  "slug": "random-guid-generator",
  "title": "Random GUID Generator",
  "desc": "Generate random GUIDs in bulk for test data, seed scripts and placeholders.",
  "ver": "4",
  "fmt": "D",
  "up": false,
  "n": 10,
  "text": [
   [
    "What is a random GUID?",
    "A random GUID is a version 4 value. Of its 128 bits, 122 come from a secure random number generator, so collisions are so unlikely that you can treat each value as unique in practice."
   ],
   [
    "Common uses",
    "Seeding databases, filling test fixtures, creating mock API responses and naming temporary files."
   ]
  ]
 },
 {
  "slug": "guid-v4-generator",
  "title": "GUID v4 Generator",
  "desc": "Create version 4 GUIDs. This is the type produced by Guid.NewGuid() in .NET.",
  "ver": "4",
  "fmt": "D",
  "up": false,
  "n": 5,
  "text": [
   [
    "What does v4 mean?",
    "The 4 is the version number, stored at the start of the third group. The first digit of the fourth group is always 8, 9, a or b. Everything else is random."
   ],
   [
    "When to use v4",
    "Use it whenever you only need a unique value. For large database tables where insert speed matters, consider v7 or a COMB GUID."
   ]
  ]
 },
 {
  "slug": "guid-v7-generator",
  "title": "GUID v7 Generator",
  "desc": "Create time-ordered version 7 GUIDs that sort by creation time.",
  "ver": "7",
  "fmt": "D",
  "up": false,
  "n": 5,
  "text": [
   [
    "What is a v7 GUID?",
    "A v7 GUID starts with a 48-bit Unix timestamp in milliseconds, followed by random bits. New values are larger than older ones, which keeps database indexes tidy."
   ],
   [
    "SQL Server note",
    "SQL Server does not sort uniqueidentifier values from the left, so v7 values will not appear in creation order there. For SQL Server, a COMB GUID is the better fit. In .NET 9 and later you can create v7 GUIDs in code with Guid.CreateVersion7()."
   ]
  ]
 },
 {
  "slug": "online-guid-generator",
  "title": "Online GUID Generator",
  "desc": "Generate GUIDs in your browser with no install and no sign-up.",
  "ver": "4",
  "fmt": "D",
  "up": false,
  "n": 5,
  "text": [
   [
    "Free and private",
    "This generator runs entirely in your browser using the Web Crypto API. Nothing you generate is sent to a server or stored."
   ],
   [
    "How to use it",
    "Choose how many GUIDs you need, pick a type and a format, and select Generate. Then copy the results or download them as a text file."
   ]
  ]
 },
 {
  "slug": "bulk-guid-generator",
  "title": "Bulk GUID Generator",
  "desc": "Create up to 1,000 GUIDs at once and download them as a text file.",
  "ver": "4",
  "fmt": "D",
  "up": false,
  "n": 100,
  "text": [
   [
    "Generate GUIDs in bulk",
    "Set the quantity (up to 1,000), select Generate, then use Copy or Download .txt. Results appear one per line, ready to paste into a spreadsheet, SQL script or seed file."
   ],
   [
    "Tips",
    "Use the SQL Server format to get each value in single quotes. Use the C# format to get code you can paste straight into a test."
   ]
  ]
 },
 {
  "slug": "guid-generator-without-dashes",
  "title": "GUID Generator Without Dashes",
  "desc": "Create GUIDs as 32 plain characters with no hyphens.",
  "ver": "4",
  "fmt": "N",
  "up": false,
  "n": 5,
  "text": [
   [
    "Why remove the dashes?",
    "Some systems store GUIDs as 32 characters, and hyphens can be awkward in file names or URLs. In .NET this is the N format: <code>Guid.NewGuid().ToString(\"N\")</code>."
   ],
   [
    "Good to know",
    "Without dashes the value is still a valid 128-bit GUID. Add the dashes back (8-4-4-4-12) when a system expects the standard form."
   ]
  ]
 },
 {
  "slug": "guid-generator-with-braces",
  "title": "GUID Generator With Braces",
  "desc": "Create GUIDs wrapped in curly braces, the style used in the Windows registry and many Microsoft tools.",
  "ver": "4",
  "fmt": "B",
  "up": true,
  "n": 5,
  "text": [
   [
    "Where braces are used",
    "Braces appear in Windows registry keys, COM class IDs, installer product codes and Visual Studio files, for example {6F9619FF-8B86-D011-B42D-00C04FC964FF}. In .NET this is the B format."
   ],
   [
    "Other wrappers",
    "Choose Parentheses (P) for the (xxxxxxxx-xxxx-...) style, or Hex array (X) for the C-style structure format."
   ]
  ]
 },
 {
  "slug": "guid-generator-for-csharp",
  "title": "GUID Generator for C#",
  "desc": "Create GUIDs as ready-to-paste C# code.",
  "ver": "4",
  "fmt": "cs",
  "up": false,
  "n": 5,
  "text": [
   [
    "Using GUIDs in C#",
    "Create one at run time with Guid.NewGuid(). To hard-code a known value, use new Guid(\"...\") or Guid.Parse(\"...\"). This generator outputs the new Guid(\"...\") form."
   ],
   [
    "Code example",
    "<pre><code>var id = Guid.NewGuid();\nvar fixedId = new Guid(\"6f9619ff-8b86-d011-b42d-00c04fc964ff\");\nstring text = id.ToString(\"D\");</code></pre>"
   ]
  ]
 },
 {
  "slug": "sql-server-guid-generator",
  "title": "SQL Server GUID Generator",
  "desc": "Create GUIDs as quoted SQL Server values.",
  "ver": "4",
  "fmt": "sql",
  "up": true,
  "n": 5,
  "text": [
   [
    "GUIDs in SQL Server",
    "SQL Server stores GUIDs in the uniqueidentifier type. NEWID() creates a random one. NEWSEQUENTIALID() creates increasing values, but it can only be used in a column default. Random GUIDs used as clustered keys can fragment the index."
   ],
   [
    "Example",
    "<pre><code>CREATE TABLE Orders (\n  Id uniqueidentifier NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY\n);\n\nINSERT INTO Orders (Id) VALUES ('6F9619FF-8B86-D011-B42D-00C04FC964FF');</code></pre>"
   ]
  ]
 },
 {
  "slug": "net-guid-generator",
  "title": "NET GUID Generator",
  "desc": "Create GUIDs and see every .NET format: D, N, B, P and X.",
  "ver": "4",
  "fmt": "D",
  "up": false,
  "n": 5,
  "text": [
   [
    "Guid.NewGuid() in .NET",
    "Guid.NewGuid() returns a random (v4) GUID. Its ToString() method accepts a format specifier, and you can pick the same formats in the Format menu above."
   ],
   [
    ".NET format specifiers",
    "<ul><li><strong>D</strong>: 32 digits with hyphens (the default)</li><li><strong>N</strong>: 32 digits, no hyphens</li><li><strong>B</strong>: hyphens inside braces</li><li><strong>P</strong>: hyphens inside parentheses</li><li><strong>X</strong>: four hex values, the last one an array of eight bytes</li></ul>"
   ],
   [
    "Code example",
    "<pre><code>var id = Guid.NewGuid();\nid.ToString(\"N\"); // 32 digits\nid.ToString(\"B\"); // {...}\nGuid.CreateVersion7(); // .NET 9 and later</code></pre>"
   ]
  ]
 },
 {
  "slug": "comb-guid-generator",
  "title": "COMB GUID Generator",
  "desc": "Create COMB GUIDs: random values with a timestamp in the last 6 bytes, so they sort in creation order in SQL Server.",
  "ver": "comb",
  "fmt": "D",
  "up": true,
  "n": 5,
  "text": [
   [
    "What is a COMB GUID?",
    "COMB stands for combined GUID and timestamp, an idea from Jimmy Nilsson. It keeps most of a random GUID but fills the last 6 bytes with the current time in milliseconds. SQL Server compares those bytes first when sorting, so new values land at the end of an index instead of at random spots."
   ],
   [
    "Is it still unique?",
    "In practice, yes. A COMB GUID keeps about 74 random bits, so duplicates remain extremely unlikely unless you create huge numbers of values in the same millisecond."
   ],
   [
    "Other databases",
    "PostgreSQL and MySQL do not sort GUIDs the way SQL Server does. Use a v7 GUID there instead."
   ]
  ]
 }
];
export const PAGE_HTML: Record<string,string> = {
 "about": "<p>DevIDTools.com is a collection of practical online utilities for developers, students, QA testers, and anyone who works with structured data. The tools on this page focus on common everyday tasks such as generating UUIDs, checking identifier formats, formatting JSON, creating random strings, and converting timestamps.</p><h2>What is a UUID?</h2><p>A Universally Unique Identifier (UUID) is a 128-bit value used to identify records, objects, events, and resources. UUIDs are commonly represented as 32 hexadecimal characters separated into five groups by hyphens. A GUID is Microsoft's term for a globally unique identifier and commonly uses the same textual format.</p><h2>UUID versions at a glance</h2><ul><li><strong>UUID v4:</strong> uses random or pseudo-random data, with version and variant bits reserved by the format.</li><li><strong>UUID v5:</strong> creates a repeatable identifier from a namespace and name using SHA-1. The same namespace and name produce the same UUID.</li><li><strong>UUID v7:</strong> includes a Unix-epoch millisecond timestamp and random data, making values generally time-sortable.</li></ul><p>Choose a version based on your application requirements. UUID v5 is useful for deterministic IDs, while v4 is a common general-purpose choice and v7 can help with time-oriented database indexing. Always check the requirements of your database, framework, and application.</p><h2>Privacy and responsible use</h2><p>These tools run their main operations locally in your browser and do not require an account. Avoid pasting passwords, access tokens, personal data, or confidential production information into any online tool unless you have reviewed its privacy and security practices. Random identifiers are not a substitute for authorization, authentication, or cryptographic key management.</p>",
 "faq": "<details><summary>Is DevIDTools.com free to use?</summary><p>Yes. The tools provided on this page are available to use without creating an account.</p></details><details><summary>What is the difference between UUID and GUID?</summary><p>UUID and GUID generally refer to the same 128-bit identifier format. GUID is a term commonly used in Microsoft ecosystems.</p></details><details><summary>Which UUID version should I choose?</summary><p>UUID v4 is a common random option, v5 is deterministic for a namespace and name, and v7 is designed to be time-sortable.</p></details><details><summary>Can I generate multiple UUIDs at once?</summary><p>Yes. Choose a quantity from 1 to 100 in the UUID generator and generate a batch.</p></details><details><summary>Does the UUID validator check whether a UUID is globally unique?</summary><p>No. It checks formatting and reports the apparent version and variant. It cannot prove that no other system has generated the same value.</p></details><details><summary>Is a UUID a secure password?</summary><p>A UUID should not be treated as a password or as the only protection for a private resource. Use a dedicated authentication and secrets-management approach.</p></details><details><summary>Why does UUID v5 need a namespace and name?</summary><p>UUID v5 combines a namespace UUID and a name to generate a stable identifier. Reusing the same inputs returns the same identifier.</p></details><details><summary>Does the JSON formatter send my data to a server?</summary><p>The formatting operation is performed in your browser by this page's JavaScript. As with any website, review hosting and privacy details before entering sensitive data.</p></details>",
 "privacy": "<p>The tools on this page are designed to process the values you enter locally in your browser. This single-page file does not include analytics, advertising scripts, or a backend form submission. Your hosting provider may collect standard server logs when you visit the website. Do not submit confidential information to tools unless you are comfortable with the site's full hosting and privacy setup.</p>",
 "terms": "<p>These utilities are provided for general informational and development purposes, without a guarantee that outputs are suitable for every use case. You are responsible for verifying results and testing them in your environment. Do not use generated values to bypass security controls or for unlawful purposes.</p>",
 "disclaimer": "<p>DevIDTools.com provides general-purpose utilities “as is” without warranties of any kind. Although care has been taken to implement common formats, software requirements can differ. Verify important values and consult your platform's official documentation before using generated data in production systems.</p>"
};
