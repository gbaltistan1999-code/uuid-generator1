import { UUID_TEXT, GUID_DATA, PAGE_HTML } from "./data.generated";
import type { GuidFmt, GuidType } from "./ids";

export const SITE_URL = "https://devidtools.com";
export type Section = [string, string];
export type Page =
  | { kind: "uuid"; slug: string; v: number; title: string; metaTitle: string; desc: string; text: string; uses: string }
  | { kind: "guid"; slug: string; title: string; metaTitle: string; desc: string; preset: { ver: GuidType; fmt: GuidFmt; up: boolean; n: number }; text: Section[] }
  | { kind: "page"; slug: string; title: string; metaTitle: string; desc: string; html: string };

const UUID_EXTRA: Record<number, { desc: string; uses: string }> = {
  1: { desc: "Generate time-based version 1 UUIDs with a random node ID. Free, instant and private.", uses: "Good for legacy systems and logs where creation time matters. Avoid it when you do not want to reveal when an ID was made." },
  2: { desc: "Generate version 2 (DCE Security) UUIDs from a domain and a local ID.", uses: "Good for almost nothing new. It exists mainly for compatibility with DCE security systems." },
  3: { desc: "Generate name-based version 3 UUIDs using MD5, a namespace and a name.", uses: "Good for matching IDs created by older systems that used MD5." },
  4: { desc: "Generate random version 4 UUIDs, one at a time or in bulk.", uses: "Good for session IDs, correlation IDs, file names and any case where you only need uniqueness." },
  5: { desc: "Generate name-based version 5 UUIDs using SHA-1, a namespace and a name.", uses: "Good for stable IDs for imported records, URLs or emails without a lookup table." },
  6: { desc: "Generate version 6 UUIDs, a sortable reordering of version 1.", uses: "Good for systems already using version 1 that want sortable IDs. For new projects, version 7 is usually better." },
  7: { desc: "Generate time-ordered version 7 UUIDs that sort by creation time.", uses: "Good for database primary keys, event logs and anything sorted by creation time." },
  8: { desc: "Generate version 8 UUIDs for custom, vendor-specific layouts.", uses: "Good for custom schemes, such as embedding a shard or tenant ID in your own layout." },
};

export const uuidSlug = (v: number) => `uuid-v${v}-generator`;
const uuidPages: Page[] = [1, 2, 3, 4, 5, 6, 7, 8].map((v) => ({
  kind: "uuid", slug: uuidSlug(v), v, title: `UUID v${v} Generator`,
  metaTitle: `UUID v${v} Generator – Free Online Tool`, desc: UUID_EXTRA[v].desc,
  text: UUID_TEXT[String(v)], uses: UUID_EXTRA[v].uses,
}));
const guidPages: Page[] = GUID_DATA.map((g) => ({
  kind: "guid", slug: g.slug, title: g.title, metaTitle: `${g.title} – Free Online Tool`, desc: g.desc,
  preset: { ver: g.ver as GuidType, fmt: g.fmt as GuidFmt, up: g.up, n: g.n }, text: g.text as Section[],
}));
const CONTACT_HTML = `<h2>Get in touch</h2><p>Questions, bug reports and ideas are welcome. Email us at <a href="mailto:contact@devidtools.com">contact@devidtools.com</a>. We aim to reply within a few working days.</p><h2>What to write to us about</h2><ul><li>A bug or wrong result in a tool. Please say which tool and what you entered.</li><li>A tool or feature you would like to see.</li><li>Business and advertising enquiries.</li></ul>`;
const staticPages: Page[] = [
  { kind: "page", slug: "about", title: "About DevIDTools", metaTitle: "About Us", desc: "Free online UUID, GUID and developer tools that run in your browser.", html: PAGE_HTML.about },
  { kind: "page", slug: "contact", title: "Contact Us", metaTitle: "Contact DevIDTools", desc: "Send a question, bug report or idea to the DevIDTools team.", html: CONTACT_HTML },
  { kind: "page", slug: "faq", title: "Frequently Asked Questions", metaTitle: "FAQ", desc: "Answers about UUIDs, GUIDs and how these tools work.", html: PAGE_HTML.faq },
  { kind: "page", slug: "privacy", title: "Privacy Policy", metaTitle: "Privacy Policy", desc: "How DevIDTools handles your data.", html: PAGE_HTML.privacy },
  { kind: "page", slug: "terms", title: "Terms of Use", metaTitle: "Terms of Use", desc: "The terms for using DevIDTools.", html: PAGE_HTML.terms },
  { kind: "page", slug: "disclaimer", title: "Disclaimer", metaTitle: "Disclaimer", desc: "Please read before relying on any generated value.", html: PAGE_HTML.disclaimer },
];
export const allPages = (): Page[] => [...uuidPages, ...guidPages, ...staticPages];
export const findPage = (slug: string) => allPages().find((p) => p.slug === slug);
export const UUID_MENU = [{ href: "/", label: "All UUID versions" }, ...uuidPages.map((p) => ({ href: `/${p.slug}`, label: p.title }))];
export const GUID_MENU = guidPages.map((p) => ({ href: `/${p.slug}`, label: p.title }));
export const HOME_HTML = `<h2>What is a UUID?</h2><p>A UUID (universally unique identifier) is a 128-bit label written as 32 hexadecimal digits in five groups, like <code>123e4567-e89b-12d3-a456-426614174000</code>. Systems use UUIDs to name records, files, sessions and messages without asking a central server for the next number.</p><h2>Which UUID version should you use?</h2><ul><li><a href="/uuid-v4-generator">Version 4</a> is random and works for most jobs.</li><li><a href="/uuid-v7-generator">Version 7</a> starts with a timestamp, so it sorts by creation time. Good for database keys.</li><li><a href="/uuid-v5-generator">Version 5</a> is built from a name and a namespace, so the same input always gives the same UUID.</li></ul><h2>UUID or GUID?</h2><p>They are the same 128-bit identifier. GUID is Microsoft&rsquo;s name for it. Need braces or uppercase? Use the <a href="/guid-generator">GUID Generator</a>.</p><h2>Is this tool private?</h2><p>Yes. UUIDs are created in your browser with the Web Crypto API. Nothing you generate is sent to a server or stored.</p>`;
