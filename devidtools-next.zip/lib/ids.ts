export function randomBytes(n: number) {
  const b = new Uint8Array(n);
  globalThis.crypto.getRandomValues(b);
  return b;
}
export const toHex = (b: Uint8Array) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
const fromHex = (h: string) => new Uint8Array((h.match(/.{2}/g) ?? []).map((x) => parseInt(x, 16)));
export const fmtUuid = (b: Uint8Array) => {
  const h = toHex(b);
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
};
export const NAMESPACES: Record<string, string> = {
  dns: "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
  url: "6ba7b811-9dad-11d1-80b4-00c04fd430c8",
  oid: "6ba7b812-9dad-11d1-80b4-00c04fd430c8",
  x500: "6ba7b814-9dad-11d1-80b4-00c04fd430c8",
};

// Random node ID and clock sequence for v1/v2/v6 (never a real MAC address).
let nodeId: Uint8Array | null = null;
let clockSeq: Uint8Array | null = null;
let lastTicks = BigInt(0);
function nodeInfo() {
  if (!nodeId || !clockSeq) {
    nodeId = randomBytes(6);
    nodeId[0] |= 1;
    clockSeq = randomBytes(2);
    clockSeq[0] = (clockSeq[0] & 0x3f) | 0x80;
  }
  return { node: nodeId, cs: clockSeq };
}
function ticks() {
  let t = BigInt(Date.now()) * BigInt(10000) + BigInt("122192928000000000");
  if (t <= lastTicks) t = lastTicks + BigInt(1);
  lastTicks = t;
  return t;
}
const by = (t: bigint, s: number) => Number((t >> BigInt(s)) & BigInt(255));

function v1() {
  const { node, cs } = nodeInfo(), t = ticks(), b = new Uint8Array(16);
  b[0] = by(t, 24); b[1] = by(t, 16); b[2] = by(t, 8); b[3] = by(t, 0);
  b[4] = by(t, 40); b[5] = by(t, 32);
  b[6] = 0x10 | (by(t, 56) & 15); b[7] = by(t, 48);
  b[8] = cs[0]; b[9] = cs[1]; b.set(node, 10);
  return b;
}
function v2(domain: number, localId: number) {
  const b = v1(), n = localId >>> 0;
  b[0] = n >>> 24; b[1] = (n >>> 16) & 255; b[2] = (n >>> 8) & 255; b[3] = n & 255;
  b[9] = domain; b[6] = (b[6] & 15) | 0x20;
  return b;
}
function v4() {
  const b = randomBytes(16);
  b[6] = (b[6] & 15) | 0x40; b[8] = (b[8] & 63) | 0x80;
  return b;
}
function v6() {
  const { node, cs } = nodeInfo(), t = ticks(), b = new Uint8Array(16);
  b[0] = by(t, 52); b[1] = by(t, 44); b[2] = by(t, 36); b[3] = by(t, 28);
  b[4] = by(t, 20); b[5] = by(t, 12);
  b[6] = 0x60 | (by(t, 8) & 15); b[7] = by(t, 0);
  b[8] = cs[0]; b[9] = cs[1]; b.set(node, 10);
  return b;
}
function v7() {
  const b = randomBytes(16);
  let ms = Date.now();
  for (let i = 5; i >= 0; i--) { b[i] = ms % 256; ms = Math.floor(ms / 256); }
  b[6] = (b[6] & 15) | 0x70; b[8] = (b[8] & 63) | 0x80;
  return b;
}
function v8() {
  const b = randomBytes(16);
  b[6] = (b[6] & 15) | 0x80; b[8] = (b[8] & 63) | 0x80;
  return b;
}
function md5(bytes: Uint8Array) {
  const K = new Uint32Array(64), S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0;
  const len = bytes.length, blocks = ((len + 8) >>> 6) + 1, buf = new Uint8Array(blocks * 64);
  buf.set(bytes); buf[len] = 0x80;
  const dv = new DataView(buf.buffer);
  dv.setUint32(blocks * 64 - 8, (len << 3) >>> 0, true);
  dv.setUint32(blocks * 64 - 4, Math.floor(len / 536870912), true);
  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
  for (let o = 0; o < blocks * 64; o += 64) {
    const M: number[] = [];
    for (let j = 0; j < 16; j++) M.push(dv.getUint32(o + j * 4, true));
    let A = a0, B = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i++) {
      let F: number, g: number;
      if (i < 16) { F = (B & C) | (~B & D); g = i; }
      else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
      else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + K[i] + M[g]) >>> 0;
      A = D; D = C; C = B;
      const s = S[(i >> 4) * 4 + (i & 3)];
      B = (B + ((F << s) | (F >>> (32 - s)))) >>> 0;
    }
    a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0; c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
  }
  const out = new Uint8Array(16), ov = new DataView(out.buffer);
  [a0, b0, c0, d0].forEach((v, i) => ov.setUint32(i * 4, v, true));
  return out;
}
async function nameUuid(v: 3 | 5, namespace: string, name: string) {
  const ns = namespace.trim().replace(/^\{|\}$/g, "").replace(/-/g, "");
  if (!/^[0-9a-f]{32}$/i.test(ns)) throw new Error("Namespace must be a valid UUID.");
  const nm = new TextEncoder().encode(name);
  const input = new Uint8Array(16 + nm.length);
  input.set(fromHex(ns)); input.set(nm, 16);
  const b = v === 5 ? new Uint8Array(await globalThis.crypto.subtle.digest("SHA-1", input)).slice(0, 16) : md5(input);
  b[6] = (b[6] & 15) | (v << 4); b[8] = (b[8] & 63) | 0x80;
  return fmtUuid(b);
}

export type UuidOpts = { ns: string; name: string; domain: number; localId: number };
export async function makeUuid(v: number, o: UuidOpts): Promise<string> {
  switch (v) {
    case 1: return fmtUuid(v1());
    case 2: return fmtUuid(v2(o.domain, o.localId));
    case 3: return nameUuid(3, o.ns, o.name);
    case 5: return nameUuid(5, o.ns, o.name);
    case 6: return fmtUuid(v6());
    case 7: return fmtUuid(v7());
    case 8: return fmtUuid(v8());
    default: return fmtUuid(v4());
  }
}

export type GuidType = "4" | "7" | "comb";
export type GuidFmt = "D" | "N" | "B" | "P" | "X" | "cs" | "sql";
export function guidHex(t: GuidType) {
  if (t === "7") return toHex(v7());
  if (t === "comb") {
    const b = randomBytes(16);
    b[6] = (b[6] & 15) | 0x40; b[8] = (b[8] & 63) | 0x80;
    let ms = Date.now();
    for (let i = 15; i >= 10; i--) { b[i] = ms % 256; ms = Math.floor(ms / 256); }
    return toHex(b);
  }
  return toHex(v4());
}
export function fmtGuid(h: string, f: GuidFmt, up: boolean) {
  const d = `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
  const U = (s: string) => (up ? s.toUpperCase() : s);
  if (f === "N") return U(h);
  if (f === "B") return U(`{${d}}`);
  if (f === "P") return U(`(${d})`);
  if (f === "X") {
    const tail = (h.slice(16).match(/../g) ?? []).map((x) => "0x" + x).join(",");
    const x = `{0x${h.slice(0, 8)},0x${h.slice(8, 12)},0x${h.slice(12, 16)},{${tail}}}`;
    return up ? x.replace(/[a-f]/g, (c) => c.toUpperCase()) : x;
  }
  if (f === "cs") return `new Guid("${U(d)}")`;
  if (f === "sql") return `'${U(d)}'`;
  return U(d);
}
