import type { MetadataRoute } from "next";
import { SITE_URL, allPages } from "@/lib/content";

export default function sitemap(): MetadataRoute.Sitemap {
  return [{ url: SITE_URL, changeFrequency: "weekly", priority: 1 }, ...allPages().map((p) => ({ url: `${SITE_URL}/${p.slug}`, changeFrequency: "monthly" as const, priority: p.kind === "page" ? 0.3 : 0.8 }))];
}
