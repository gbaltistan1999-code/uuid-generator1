import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import UuidTool from "@/components/UuidTool";
import GuidTool from "@/components/GuidTool";
import { GUID_MENU, UUID_MENU, allPages, findPage } from "@/lib/content";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return allPages().map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = findPage(slug);
  if (!p) return {};
  return {
    title: p.metaTitle,
    description: p.desc,
    alternates: { canonical: `/${slug}` },
    openGraph: { title: p.metaTitle, description: p.desc, url: `/${slug}`, type: "website" },
  };
}

const Links = ({ items, current }: { items: { href: string; label: string }[]; current: string }) => (
  <ul className="rel">{items.filter((i) => i.href !== current).map((i) => <li key={i.href}><Link href={i.href}>{i.label}</Link></li>)}</ul>
);

export default async function Page({ params }: Props) {
  const { slug } = await params;
  const p = findPage(slug);
  if (!p) notFound();
  const here = `/${slug}`;

  if (p.kind === "uuid") {
    return (
      <>
        <section className="hero"><div className="wrap">
          <span className="eyebrow">UUID Tools</span>
          <h1><span className="uniq">{p.title}</span></h1>
          <UuidTool key={slug} version={p.v} />
        </div></section>
        <main className="wrap"><article className="content">
          <h2>What is a Version {p.v} UUID?</h2><p>{p.text}</p>
          <h2>When to use it</h2><p>{p.uses}</p>
          <h2>Other UUID versions</h2><Links items={UUID_MENU.filter((i) => i.href !== "/")} current={here} />
        </article></main>
      </>
    );
  }
  if (p.kind === "guid") {
    return (
      <>
        <section className="hero"><div className="wrap">
          <span className="eyebrow">GUID Tools</span>
          <h1><span className="uniq">{p.title}</span></h1>
          <p>{p.desc}</p>
        </div></section>
        <main className="wrap">
          <section className="panel" style={{ marginTop: 24 }}><GuidTool key={slug} preset={p.preset} /></section>
          <article className="content">
            {p.text.map(([h, body]) => (
              <div key={h}><h2>{h}</h2>{body.startsWith("<") ? <div dangerouslySetInnerHTML={{ __html: body }} /> : <p>{body}</p>}</div>
            ))}
            <h2>More GUID tools</h2><Links items={GUID_MENU} current={here} />
          </article>
        </main>
      </>
    );
  }
  return (
    <>
      <section className="hero"><div className="wrap"><h1><span className="uniq">{p.title}</span></h1></div></section>
      <main className="wrap"><article className="content" dangerouslySetInnerHTML={{ __html: p.html }} /></main>
    </>
  );
}
