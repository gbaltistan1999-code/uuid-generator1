import type { Metadata } from "next";
import Link from "next/link";
import UuidTool from "@/components/UuidTool";
import { HOME_HTML, UUID_MENU } from "@/lib/content";

export const metadata: Metadata = {
  title: { absolute: "Online UUID Generator – Free UUID v1 to v8 | DevIDTools" },
  description: "Generate UUIDs online: versions 1 to 8, in bulk, with or without hyphens. Free and private, runs in your browser.",
  alternates: { canonical: "/" },
};

export default function Home() {
  return (
    <>
      <section className="hero"><div className="wrap">
        <span className="eyebrow">Free UUID Generator &amp; Online Developer Tools</span>
        <h1><span className="uniq">Online UUID Generator</span></h1>
        <UuidTool version={4} />
      </div></section>
      <main className="wrap">
        <article className="content" dangerouslySetInnerHTML={{ __html: HOME_HTML }} />
        <section className="content"><h2>All UUID tools</h2>
          <ul className="rel">{UUID_MENU.slice(1).map((i) => <li key={i.href}><Link href={i.href}>{i.label}</Link></li>)}</ul></section>
      </main>
    </>
  );
}
