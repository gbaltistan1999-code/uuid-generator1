DevIDTools - separate pages for UUID and GUID tools (Next.js, App Router, TypeScript)

1. Copy the three folders in this zip (app, components, lib) into your yoursite-tools project.
   Say yes to replace app/layout.tsx, app/page.tsx and app/globals.css.
   You can delete app/page.module.css (not used).
2. In the project folder run:   npm run dev
3. Open http://localhost:3000

Pages created (each with its own address, title and description):
  /                          Online UUID Generator (v4)
  /uuid-v1-generator ... /uuid-v8-generator
  /guid-generator, /random-guid-generator, /guid-v4-generator, /guid-v7-generator,
  /online-guid-generator, /bulk-guid-generator, /guid-generator-without-dashes,
  /guid-generator-with-braces, /guid-generator-for-csharp, /sql-server-guid-generator,
  /net-guid-generator, /comb-guid-generator
  /about /contact /faq /privacy /terms /disclaimer
  /sitemap.xml and /robots.txt are generated automatically.

Before going live:
  - Set your real domain in lib/content.ts (SITE_URL).
  - Replace contact@devidtools.com in lib/content.ts with your real email.
  - Edit page text in lib/content.ts and lib/data.generated.ts.
