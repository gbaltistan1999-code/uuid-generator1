import Link from "next/link";

export default function Logo({ light }: { light?: boolean }) {
  const id = light ? "lgB" : "lgA";
  return (
    <Link className="logo" href="/" aria-label="DevIDTools home" style={light ? { color: "#fff" } : undefined}>
      <svg className="mark" width="38" height="38" viewBox="0 0 40 40" aria-hidden="true">
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#7c3aed" />
            <stop offset="1" stopColor="#e11d48" />
          </linearGradient>
        </defs>
        <rect width="40" height="40" rx="11" fill={`url(#${id})`} />
        <g fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <path d="M16 11c-3 0-4 1.2-4 4v2c0 1.6-.8 3-2.5 3 1.7 0 2.5 1.4 2.5 3v2c0 2.8 1 4 4 4" />
          <path d="M24 11c3 0 4 1.2 4 4v2c0 1.6.8 3 2.5 3-1.7 0-2.5 1.4-2.5 3v2c0 2.8-1 4-4 4" />
        </g>
        <g fill="#fff">
          <rect x="17.5" y="15" width="5" height="2.2" rx="1.1" />
          <rect x="15.5" y="18.9" width="9" height="2.2" rx="1.1" />
          <rect x="17.5" y="22.8" width="5" height="2.2" rx="1.1" />
        </g>
      </svg>
      <b>Dev<span>ID</span>Tools</b>
    </Link>
  );
}
