import Link from "next/link";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="wrap footrow">
        <div>
          <Logo light />
          <p>Simple, useful utilities for everyday development.</p>
        </div>
        <div>
          <Link href="/about">About</Link> · <Link href="/contact">Contact</Link> · <Link href="/privacy">Privacy</Link> · <Link href="/terms">Terms</Link> · <Link href="/disclaimer">Disclaimer</Link> · <Link href="/faq">FAQs</Link>
          <p>© 2026 DevIDTools</p>
        </div>
      </div>
    </footer>
  );
}
