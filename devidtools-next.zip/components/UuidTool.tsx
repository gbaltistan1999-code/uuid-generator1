"use client";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { NAMESPACES, makeUuid } from "@/lib/ids";
import { uuidSlug } from "@/lib/content";
import { copyText, downloadText } from "./useCopy";

export default function UuidTool({ version }: { version: number }) {
  const [upper, setUpper] = useState(false);
  const [hyphens, setHyphens] = useState(true);
  const [braces, setBraces] = useState(false);
  const [ns, setNs] = useState("dns");
  const [customNs, setCustomNs] = useState("");
  const [name, setName] = useState("");
  const [domain, setDomain] = useState(0);
  const [localId, setLocalId] = useState(1000);
  const [count, setCount] = useState("");
  const [single, setSingle] = useState("");
  const [bulk, setBulk] = useState("");
  const [msg, setMsg] = useState("");
  const [bad, setBad] = useState(false);

  const make = useCallback(async (n: number) => {
    const out: string[] = [];
    const o = { ns: ns === "custom" ? customNs : NAMESPACES[ns], name: name || "example.com", domain, localId };
    for (let i = 0; i < n; i++) {
      let s = await makeUuid(version, o);
      if (!hyphens) s = s.replace(/-/g, "");
      if (braces) s = `{${s}}`;
      out.push(upper ? s.toUpperCase() : s);
    }
    return out;
  }, [version, ns, customNs, name, domain, localId, hyphens, braces, upper]);

  const one = useCallback(async () => {
    try { setSingle((await make(1))[0]); setMsg(""); setBad(false); }
    catch (e) { setMsg((e as Error).message); setBad(true); }
  }, [make]);

  useEffect(() => { void one(); }, [version, hyphens, braces, upper]); // eslint-disable-line react-hooks/exhaustive-deps

  const label = `Version ${version}`;
  const named = version === 3 || version === 5;
  const say = (m: string, isBad = false) => { setMsg(m); setBad(isBad); };

  return (
    <div className="gen">
      <div className="gen-head"><h2>{label} UUID Generator</h2></div>
      <div className="gen-body">
        <div className="seg" role="group" aria-label="UUID version">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((v) => (
            <Link key={v} href={v === 4 ? "/" : `/${uuidSlug(v)}`} className={v === version ? "on" : ""} style={{ display: "inline-block", textDecoration: "none" }}>
              <span className="segl">Version {v}</span>
            </Link>
          ))}
        </div>
        {named && (
          <div className="ns">
            <select value={ns} onChange={(e) => setNs(e.target.value)} aria-label="Namespace">
              <option value="dns">Namespace: DNS</option>
              <option value="url">Namespace: URL</option>
              <option value="oid">Namespace: OID</option>
              <option value="x500">Namespace: X.500</option>
              <option value="custom">Namespace: custom UUID</option>
            </select>
            {ns === "custom" && <input className="input" value={customNs} onChange={(e) => setCustomNs(e.target.value)} placeholder="Custom namespace UUID" aria-label="Custom namespace UUID" />}
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name, for example example.com" aria-label="Name" />
          </div>
        )}
        {version === 2 && (
          <div className="ns">
            <select value={domain} onChange={(e) => setDomain(Number(e.target.value))} aria-label="Domain">
              <option value={0}>Domain: Person (POSIX UID)</option>
              <option value={1}>Domain: Group (POSIX GID)</option>
              <option value={2}>Domain: Organization</option>
            </select>
            <input className="input" type="number" min={0} value={localId} onChange={(e) => setLocalId(Number(e.target.value))} aria-label="Local ID" placeholder="Local ID" />
          </div>
        )}
        <div className="center"><button type="button" className="bigbtn" onClick={one}>Generate a {label} UUID</button></div>
        {single && (
          <div className="single">
            <code>{single}</code>
            <button type="button" className="btn small" onClick={async () => say((await copyText(single)) ? "Copied to clipboard." : "Copy failed.", false)}>Copy</button>
          </div>
        )}
        <div className="opts">
          <label>Letter case <select value={upper ? "u" : "l"} onChange={(e) => setUpper(e.target.value === "u")}><option value="l">lowercase</option><option value="u">UPPERCASE</option></select></label>
          <label><input type="checkbox" checked={hyphens} onChange={(e) => setHyphens(e.target.checked)} /> Hyphens</label>
          <label><input type="checkbox" checked={braces} onChange={(e) => setBraces(e.target.checked)} /> Braces</label>
        </div>
        <hr />
        <h3>Bulk {label} UUID Generation</h3>
        <div className="bulk">
          <label htmlFor="cnt">How many?</label>
          <input id="cnt" type="number" min={1} max={500} placeholder="Max 500" value={count} onChange={(e) => setCount(e.target.value)} />
          <button type="button" className="blk" onClick={async () => {
            try { const n = Math.max(1, Math.min(500, parseInt(count, 10) || 1)); setBulk((await make(n)).join("\n")); say(`Generated ${n}.`); }
            catch (e) { say((e as Error).message, true); }
          }}>Generate</button>
          <a href="#" onClick={(e) => { e.preventDefault(); if (!bulk.trim()) say("Generate some UUIDs first.", true); else downloadText("uuids.txt", bulk); }}>Download to a file</a>
        </div>
        <textarea readOnly value={bulk} placeholder="Your bulk UUIDs will appear here" aria-label="Bulk results" />
        <div className="row" style={{ marginTop: 10 }}>
          <button type="button" className="btn small" onClick={async () => say((await copyText(bulk)) ? "Copied to clipboard." : "Nothing to copy.", false)}>Copy results</button>
          <span className={"status " + (bad ? "bad" : "good")} aria-live="polite">{msg}</span>
        </div>
      </div>
    </div>
  );
}
