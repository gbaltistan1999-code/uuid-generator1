"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "./Logo";
import { GUID_MENU, UUID_MENU } from "@/lib/content";

type Item = { href: string; label: string };

function Menu({ id, label, items, open, setOpen }: { id: string; label: string; items: Item[]; open: string | null; setOpen: (v: string | null) => void }) {
  const isOpen = open === id;
  return (
    <div className={"dd" + (isOpen ? " open" : "")}>
      <button type="button" className="ddt" aria-expanded={isOpen} aria-haspopup="true"
        onClick={(e) => { e.stopPropagation(); setOpen(isOpen ? null : id); }}>
        {label} &#9662;
      </button>
      <div className="ddm">
        {items.map((i) => (
          <Link key={i.href} href={i.href} onClick={() => setOpen(null)}>{i.label}</Link>
        ))}
      </div>
    </div>
  );
}

export default function Header() {
  const [open, setOpen] = useState<string | null>(null);
  const path = usePathname();
  useEffect(() => setOpen(null), [path]);
  useEffect(() => {
    const close = () => setOpen(null);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, []);
  return (
    <header className="header">
      <div className="wrap headrow">
        <Logo />
        <nav aria-label="Main navigation">
          <Link href="/">Home</Link>
          <Menu id="uuid" label="UUID Tools" items={UUID_MENU} open={open} setOpen={setOpen} />
          <Menu id="guid" label="GUID Tools" items={GUID_MENU} open={open} setOpen={setOpen} />
          <Link href="/about">About</Link>
          <Link href="/contact">Contact</Link>
        </nav>
      </div>
    </header>
  );
}
