"use client";
import { useEffect, useState } from "react";
import { fmtGuid, guidHex, type GuidFmt, type GuidType } from "@/lib/ids";
import { copyText, downloadText } from "./useCopy";

export type Preset = { ver: GuidType; fmt: GuidFmt; up: boolean; n: number };

export default function GuidTool({ preset }: { preset: Preset }) {
  const [count, setCount] = useState(preset.n);
  const [ver, setVer] = useState<GuidType>(preset.ver);
  const [fmt, setFmt] = useState<GuidFmt>(preset.fmt);
  const [up, setUp] = useState(preset.up);
  const [out, setOut] = useState("");
  const [msg, setMsg] = useState("");
  const [bad, setBad] = useState(false);

  const gen = () => {
    const n = Math.max(1, Math.min(1000, Math.floor(count) || 1));
    setOut(Array.from({ length: n }, () => fmtGuid(guidHex(ver), fmt, up)).join("\n"));
    setMsg(`Generated ${n} GUID(s).`); setBad(false);
  };
  useEffect(gen, [ver, fmt, up]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <div className="row">
        <div className="field"><label htmlFor="gc">Quantity (1–1000)</label>
          <input id="gc" className="input" type="number" min={1} max={1000} value={count} onChange={(e) => setCount(Number(e.target.value))} onBlur={gen} /></div>
        <div className="field"><label htmlFor="gv">Type</label>
          <select id="gv" className="input" value={ver} onChange={(e) => setVer(e.target.value as GuidType)}>
            <option value="4">Random (v4)</option><option value="7">Time-ordered (v7)</option><option value="comb">COMB (sequential)</option>
          </select></div>
        <div className="field"><label htmlFor="gf">Format</label>
          <select id="gf" className="input" value={fmt} onChange={(e) => setFmt(e.target.value as GuidFmt)}>
            <option value="D">Hyphens (D)</option><option value="N">No dashes (N)</option><option value="B">Braces (B)</option>
            <option value="P">Parentheses (P)</option><option value="X">Hex array (X)</option><option value="cs">C# code</option><option value="sql">SQL Server</option>
          </select></div>
      </div>
      <div className="checks"><label><input type="checkbox" checked={up} onChange={(e) => setUp(e.target.checked)} /> Uppercase</label></div>
      <div className="row" style={{ marginTop: 14 }}>
        <button className="btn primary" type="button" onClick={gen}>Generate GUIDs</button>
        <button className="btn" type="button" onClick={async () => { const ok = await copyText(out); setMsg(ok ? "Copied to clipboard." : "Nothing to copy."); setBad(!ok); }}>Copy GUIDs</button>
        <button className="btn" type="button" onClick={() => downloadText("guids.txt", out)}>Download .txt</button>
      </div>
      <div className="field"><label htmlFor="go">Results</label>
        <textarea id="go" readOnly value={out} placeholder="Your GUIDs will appear here…" />
        <div className={"status " + (bad ? "bad" : "good")} aria-live="polite">{msg}</div></div>
    </>
  );
}
